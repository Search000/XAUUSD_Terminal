import * as React from "react";
import { useState } from "react";
import { useListLicenses, getListLicensesQueryKey, useGenerateLicense, useDeleteLicense } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LicenseStatusBadge, formatDaysLeft } from "@/components/shared/LicenseHelpers";
import { format } from "date-fns";
import { Copy, CheckCircle, Trash2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export function LicensesPage() {
  const queryClient = useQueryClient();
  const { data: licenses, isLoading } = useListLicenses({ query: { queryKey: getListLicensesQueryKey() } });
  
  const generate = useGenerateLicense({ 
    mutation: { 
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListLicensesQueryKey() });
      }
    } 
  });
  
  const deleteLicense = useDeleteLicense({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListLicensesQueryKey() });
        setConfirmingDeleteId(null);
      }
    }
  });

  const [transactionCode, setTransactionCode] = useState("");
  const [durationDays, setDurationDays] = useState("30");
  const [note, setNote] = useState("");
  const [generatedCode, setGeneratedCode] = useState("");
  const [copied, setCopied] = useState(false);
  const [confirmingDeleteId, setConfirmingDeleteId] = useState<number | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transactionCode || !durationDays) return;
    try {
      const res = await generate.mutateAsync({
        data: {
          transactionCode,
          durationDays: parseInt(durationDays, 10),
          note: note || undefined
        }
      });
      setGeneratedCode(res.licenseCode);
      setTransactionCode("");
      setNote("");
    } catch (err) {
      console.error(err);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDelete = (id: number) => {
    setConfirmingDeleteId(currentId => currentId === id ? null : id);
  };

  const sortedLicenses = licenses?.slice().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()) || [];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">License Management</h2>
        <p className="text-muted-foreground">Generate, view, and delete access licenses.</p>
      </div>

      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="text-primary text-xl">Generate New License</CardTitle>
          <CardDescription>Issue a new license code for a customer based on their payment transaction.</CardDescription>
        </CardHeader>
        <form onSubmit={handleGenerate}>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="txCode">Transaction Ref / Order ID</Label>
                <Input 
                  id="txCode" 
                  value={transactionCode} 
                  onChange={(e) => setTransactionCode(e.target.value)} 
                  placeholder="e.g. pi_3M..."
                  required
                  className="font-mono bg-background"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duration">Duration (Days)</Label>
                <Input 
                  id="duration" 
                  type="number" 
                  min="1"
                  value={durationDays} 
                  onChange={(e) => setDurationDays(e.target.value)} 
                  required
                  className="data-number bg-background"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="note">Admin Note (Optional)</Label>
                <Input 
                  id="note" 
                  value={note} 
                  onChange={(e) => setNote(e.target.value)} 
                  placeholder="e.g. VIP Customer"
                  className="bg-background"
                />
              </div>
            </div>
            
            {generatedCode && (
              <div className="mt-6 p-4 bg-background border border-primary/30 rounded-lg flex items-center justify-between animate-in fade-in zoom-in-95 duration-300">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Generated License Code</p>
                  <p className="text-2xl font-mono tracking-wider text-primary">{generatedCode}</p>
                </div>
                <Button type="button" variant="secondary" onClick={handleCopy} className="gap-2">
                  {copied ? <CheckCircle className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                  {copied ? "Copied" : "Copy Code"}
                </Button>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={generate.isPending} className="w-full md:w-auto">
              {generate.isPending ? "Generating..." : "Generate License"}
            </Button>
          </CardFooter>
        </form>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>License Registry</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Transaction</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Expires</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading && (
                <TableRow>
                  <TableCell colSpan={8} className="h-32 text-center">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <svg className="w-5 h-5 text-primary animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                      <span className="text-xs font-mono text-muted-foreground uppercase tracking-widest">Loading Licenses...</span>
                    </div>
                  </TableCell>
                </TableRow>
              )}
              {sortedLicenses.map((lic) => (
                <TableRow key={lic.id}>
                  <TableCell className="font-mono">{lic.licenseCode}</TableCell>
                  <TableCell className="font-mono text-muted-foreground">{lic.transactionCode}</TableCell>
                  <TableCell><LicenseStatusBadge license={lic} /></TableCell>
                  <TableCell>{lic.usedByEmail || <span className="text-muted-foreground">-</span>}</TableCell>
                  <TableCell className="data-number">{lic.durationDays}d</TableCell>
                  <TableCell>
                    {lic.expiresAt ? (
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-mono">{format(new Date(lic.expiresAt), "MMM d, yyyy")}</span>
                        <span className="text-[10px] text-muted-foreground">{formatDaysLeft(lic.expiresAt)}</span>
                      </div>
                    ) : <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell className="text-muted-foreground">{format(new Date(lic.createdAt), "MMM d, yyyy")}</TableCell>
                   <TableCell className="text-right">
                    {confirmingDeleteId === lic.id ? (
                       <div className="flex items-center justify-end gap-2">
                         <span className="text-xs text-destructive whitespace-nowrap">Delete?</span>
                         <Button
                           variant="destructive"
                           size="sm"
                           className="h-8 px-2"
                           onClick={async () => {
                             await deleteLicense.mutateAsync({ id: lic.id });
                           }}
                           disabled={deleteLicense.isPending}
                         >
                           {deleteLicense.isPending ? "Deleting…" : "Confirm"}
                         </Button>
                         <Button
                           variant="ghost"
                           size="sm"
                           className="h-8 px-2"
                           onClick={() => setConfirmingDeleteId(null)}
                           disabled={deleteLicense.isPending}
                         >
                           Cancel
                         </Button>
                       </div>
                     ) : (
                       <Button
                         variant="ghost"
                         size="sm"
                         className="text-destructive hover:bg-destructive/10 hover:text-destructive h-8 px-2"
                         onClick={() => handleDelete(lic.id)}
                         disabled={deleteLicense.isPending}
                         aria-label={`Delete license ${lic.licenseCode}`}
                       >
                         <Trash2 className="h-4 w-4 mr-1" />
                         Delete
                       </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {!isLoading && sortedLicenses.length === 0 && (
                <TableRow>
                  <TableCell colSpan={8} className="text-center text-muted-foreground p-8">No licenses generated yet.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
