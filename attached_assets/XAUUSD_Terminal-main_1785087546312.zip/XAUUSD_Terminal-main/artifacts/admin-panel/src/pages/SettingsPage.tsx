import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { customFetch } from "@workspace/api-client-react";

async function getSystemSettings() {
  return customFetch<{ licenseEnforcementEnabled: boolean }>("/api/admin/system-settings");
}

async function updateSystemSettings(payload: { licenseEnforcementEnabled: boolean }) {
  return customFetch<{ licenseEnforcementEnabled: boolean }>("/api/admin/system-settings", {
    method: "PUT",
    body: JSON.stringify(payload),
  });
}

export function SettingsPage() {
  const qc = useQueryClient();
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["admin", "system-settings"],
    queryFn: getSystemSettings,
  });

  const mutation = useMutation({
    mutationFn: updateSystemSettings,
    onMutate: () => setSaving(true),
    onSuccess: (updated) => {
      qc.setQueryData(["admin", "system-settings"], updated);
      setSaving(false);
      setToast({ msg: "Settings saved.", ok: true });
      setTimeout(() => setToast(null), 3000);
    },
    onError: () => {
      setSaving(false);
      setToast({ msg: "Save failed.", ok: false });
      setTimeout(() => setToast(null), 3000);
    },
  });

  const toggle = () => {
    if (!data) return;
    mutation.mutate({ licenseEnforcementEnabled: !data.licenseEnforcementEnabled });
  };

  const enforced = data?.licenseEnforcementEnabled ?? true;

  return (
    <div className="p-6 space-y-8 max-w-2xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold font-mono tracking-tight">System Settings</h1>
        <p className="text-sm text-muted-foreground mt-1">Global platform configuration.</p>
      </div>

      {/* License Enforcement Card */}
      <div className="border border-border rounded-lg bg-card p-6 space-y-4">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="font-semibold text-base">License Enforcement</h2>
            <p className="text-sm text-muted-foreground mt-1">
              When <strong>ON</strong>, all users must have a valid active license to access the terminal.<br />
              When <strong>OFF</strong>, license checks are bypassed globally — everyone can log in.
            </p>
          </div>
          <button
            disabled={isLoading || saving}
            onClick={toggle}
            aria-label="Toggle license enforcement"
            className={`relative inline-flex h-7 w-14 flex-shrink-0 cursor-pointer rounded-full border-2 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background disabled:opacity-50 ${
              enforced ? "bg-primary border-primary" : "bg-muted border-muted"
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 mt-[1px] rounded-full bg-white shadow ring-0 transition-transform duration-200 ${
                enforced ? "translate-x-7" : "translate-x-0"
              }`}
            />
          </button>
        </div>

        {/* Status badge */}
        <div className="flex items-center gap-2 pt-2">
          <span
            className={`inline-flex items-center gap-1.5 text-xs font-mono px-2.5 py-1 rounded-full border ${
              enforced
                ? "border-green-500/30 bg-green-500/10 text-green-400"
                : "border-amber-500/30 bg-amber-500/10 text-amber-400"
            }`}
          >
            <span className={`h-1.5 w-1.5 rounded-full ${enforced ? "bg-green-400" : "bg-amber-400"}`} />
            {isLoading ? "Loading…" : enforced ? "ENFORCED — License required" : "OPEN — No license required"}
          </span>
          {saving && <span className="text-xs text-muted-foreground font-mono">Saving…</span>}
        </div>

        {/* Warning when turned off */}
        {!isLoading && !enforced && (
          <div className="rounded-md border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-300">
            ⚠️ License enforcement is currently <strong>OFF</strong>. Any authenticated user can access the
            terminal without a license. Turn this back ON when your license campaign is ready.
          </div>
        )}
      </div>

      {/* Toast */}
      {toast && (
        <div
          className={`fixed bottom-6 right-6 z-50 rounded-md border px-4 py-3 text-sm font-mono shadow-lg ${
            toast.ok
              ? "border-green-500/30 bg-green-500/10 text-green-300"
              : "border-red-500/30 bg-red-500/10 text-red-300"
          }`}
        >
          {toast.msg}
        </div>
      )}
    </div>
  );
}
