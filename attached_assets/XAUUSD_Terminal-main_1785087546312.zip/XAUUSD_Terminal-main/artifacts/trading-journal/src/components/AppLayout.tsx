import {
  useGetLicenseStatus,
  getGetLicenseStatusQueryKey,
  useGetInvestorShares,
  getGetInvestorSharesQueryKey,
  useGetAccountSettings,
  getGetAccountSettingsQueryKey,
} from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { useUser, useClerk } from "@clerk/react";
import { useTheme } from "next-themes";
import {
  Activity,
  LayoutDashboard,
  FileText,
  BarChart2,
  Users,
  Settings,
  LogOut,
  Eye,
  EyeOff,
  Sun,
  Moon,
  Wallet,
  Star,
} from "lucide-react";
import { Link } from "wouter";
import { NotificationPanel } from "./NotificationPanel";
import { NicknameModal } from "./NicknameModal";

export function AppLayout({
  children,
  hideNav = false,
}: {
  children: React.ReactNode;
  hideNav?: boolean;
}) {
  const [location, setLocation] = useLocation();
  const { user, isLoaded, isSignedIn } = useUser();
  const { signOut } = useClerk();
  const { theme, setTheme } = useTheme();
  const [isBalanceVisible, setIsBalanceVisible] = useState(false);

  const { data: license, isLoading: isLicenseLoading } = useGetLicenseStatus({
    query: {
      queryKey: getGetLicenseStatusQueryKey(),
      enabled: isLoaded && !!isSignedIn,
    },
  });

  const { data: shares } = useGetInvestorShares({
    query: {
      queryKey: getGetInvestorSharesQueryKey(),
      enabled: isLoaded && !!isSignedIn,
    },
  });

  const { data: accountSettings } = useGetAccountSettings({
    query: {
      queryKey: getGetAccountSettingsQueryKey(),
      enabled: isLoaded && !!isSignedIn,
    },
  });

  const liveBalance = shares?.currentBalance ?? 0;

  // Display name priority: nickname > full name > username > email prefix
  const nickname = accountSettings?.nickname?.trim() || null;
  const fallbackName =
    user?.fullName?.trim() ||
    [user?.firstName, user?.lastName].filter(Boolean).join(" ") ||
    user?.username ||
    user?.primaryEmailAddress?.emailAddress?.split("@")[0] ||
    "Trader";
  const displayName = nickname ?? fallbackName;

  useEffect(() => {
    if (
      isLoaded &&
      !isSignedIn &&
      location !== "/" &&
      location !== "/sign-in" &&
      location !== "/sign-up"
    ) {
      setLocation("/");
    }
  }, [isLoaded, isSignedIn, location, setLocation]);

  useEffect(() => {
    if (isLoaded && isSignedIn && !isLicenseLoading) {
      if (
        license?.licenseEnforcementEnabled === false &&
        location === "/activate"
      ) {
        setLocation("/dashboard");
      } else if (
        license?.licenseEnforcementEnabled !== false &&
        !license?.isActive &&
        location !== "/activate"
      ) {
        setLocation("/activate");
      }
    }
  }, [license, isLicenseLoading, location, setLocation, isLoaded, isSignedIn]);

  if (!isLoaded || (!!isSignedIn && isLicenseLoading)) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center">
        <Activity className="w-8 h-8 text-primary animate-pulse mb-4" />
        <p className="text-sm font-mono text-muted-foreground uppercase tracking-widest">
          Connecting to Terminal...
        </p>
      </div>
    );
  }

  const navLinks = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/trades", label: "Trade Log", icon: FileText },
    { href: "/reports", label: "Reports", icon: BarChart2 },
    { href: "/investors", label: "Investors", icon: Users },
    { href: "/score", label: "Score", icon: Star },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col text-foreground font-sans">
      {/* Nickname prompt — shown once on first login */}
      {isSignedIn && <NicknameModal isSignedIn={!!isSignedIn} />}

      {!hideNav && (
        <>
          {/* ── TOP HEADER ── */}
          <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
            <div className="container mx-auto px-4 h-14 flex items-center justify-between">
              {/* Logo */}
              <Link
                href="/dashboard"
                className="flex items-center gap-2 text-primary hover:opacity-80 transition-opacity"
              >
                <Activity className="w-5 h-5" />
                <span className="font-bold tracking-tight text-lg leading-none mt-0.5">
                  XAUUSD
                </span>
              </Link>

              {/* Desktop nav */}
              <nav className="hidden md:flex items-center gap-1 mx-6 flex-1">
                {navLinks.map((link) => (
                  <NavButton
                    key={link.href}
                    href={link.href}
                    active={location === link.href}
                  >
                    {link.label}
                  </NavButton>
                ))}
              </nav>

              {/* Right side */}
              <div className="flex items-center gap-2">
                {/* Dark / Light toggle */}
                <button
                  type="button"
                  onClick={() =>
                    setTheme(theme === "dark" ? "light" : "dark")
                  }
                  className="text-muted-foreground hover:text-primary transition-colors p-1.5 rounded border border-border hover:border-primary/40"
                  aria-label="Toggle theme"
                  title={
                    theme === "dark"
                      ? "Switch to light mode"
                      : "Switch to dark mode"
                  }
                >
                  {theme === "dark" ? (
                    <Sun className="w-4 h-4" />
                  ) : (
                    <Moon className="w-4 h-4" />
                  )}
                </button>

                {/* Notification Bell */}
                {isSignedIn && <NotificationPanel />}

                {/* Nickname / BL display */}
                {isSignedIn && (
                  <div className="hidden sm:flex items-center gap-2 rounded border border-border bg-secondary/30 px-2.5 py-1.5">
                    {/* Callsign */}
                    <span
                      className="text-xs font-mono text-slate-300 max-w-[110px] truncate"
                      title={displayName}
                    >
                      {displayName}
                    </span>

                    <span className="text-border select-none">|</span>

                    {/* Live Balance */}
                    <div className="flex items-center gap-1.5">
                      <Wallet className="w-3 h-3 text-primary shrink-0" />
                      <span className="text-xs font-mono text-primary font-semibold">
                        {isBalanceVisible
                          ? `$${liveBalance.toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}`
                          : "••••••"}
                      </span>
                      <button
                        type="button"
                        onClick={() => setIsBalanceVisible((v) => !v)}
                        className="shrink-0 text-muted-foreground transition-colors hover:text-primary focus:outline-none"
                        aria-label={
                          isBalanceVisible ? "Hide balance" : "Show balance"
                        }
                        title={
                          isBalanceVisible ? "Hide balance" : "Show balance"
                        }
                      >
                        {isBalanceVisible ? (
                          <EyeOff className="h-3.5 w-3.5" />
                        ) : (
                          <Eye className="h-3.5 w-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                )}

                {/* Status indicator */}
                <div className="text-right hidden sm:block">
                  <div className="text-xs text-muted-foreground font-mono">
                    STATUS
                  </div>
                  <div className="text-xs text-green-500 font-mono flex items-center gap-1.5 justify-end">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                    <span className="hidden sm:inline">LIVE</span>
                  </div>
                </div>

                <button
                  onClick={() => signOut()}
                  className="text-xs font-mono uppercase tracking-wider text-red-400 border border-red-500/30 bg-red-500/10 hover:bg-red-500/20 hover:text-red-300 transition-colors px-2.5 py-1.5 rounded flex items-center gap-1.5"
                  title="Sign out"
                  aria-label="Sign out"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="hidden md:inline">Sign out</span>
                </button>
              </div>
            </div>
          </header>

          {/* ── MOBILE BOTTOM NAV ── */}
          <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border flex items-stretch">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = location === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`flex-1 flex flex-col items-center justify-center py-2 gap-0.5 transition-colors ${
                    isActive
                      ? "text-primary bg-secondary/60"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary/30"
                  }`}
                >
                  <Icon
                    className={`w-5 h-5 ${isActive ? "text-primary" : ""}`}
                  />
                  <span
                    className={`text-[10px] font-mono uppercase tracking-wider ${
                      isActive ? "text-primary" : ""
                    }`}
                  >
                    {link.label}
                  </span>
                </Link>
              );
            })}
          </nav>
        </>
      )}

      {/* Sign-out when hideNav */}
      {hideNav && isSignedIn && (
        <div className="absolute top-4 right-4 z-50">
          <button
            onClick={() => signOut()}
            className="text-xs font-mono uppercase tracking-wider text-red-400 border border-red-500/40 bg-red-500/10 hover:bg-red-500/20 hover:text-red-300 transition-colors px-3 py-2 rounded-md flex items-center gap-2 shadow-[0_0_16px_rgba(239,68,68,0.12)]"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign out</span>
          </button>
        </div>
      )}

      {/* Main content */}
      <main
        className={`flex-1 flex flex-col ${!hideNav ? "pb-16 md:pb-0" : ""}`}
      >
        {children}
      </main>
    </div>
  );
}

function NavButton({
  href,
  active,
  children,
}: {
  href: string;
  active: boolean;
  children: React.ReactNode;
}) {
  return (
    <Link href={href}>
      <span
        className={`px-3 py-1.5 rounded text-sm font-medium transition-colors ${
          active
            ? "bg-secondary text-foreground"
            : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
        }`}
      >
        {children}
      </span>
    </Link>
  );
}
