import { AppLayout } from "@/components/AppLayout";
import { useGetAchievements, getGetAchievementsQueryKey } from "@workspace/api-client-react";
import { cn } from "@/lib/utils";

function ProgressBar({ value, className }: { value: number; className?: string }) {
  return (
    <div className={cn("h-1.5 w-full rounded-full bg-secondary/60 overflow-hidden", className)}>
      <div
        className="h-full rounded-full bg-primary transition-all duration-700"
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}

export default function AchievementsPage() {
  const { data, isLoading } = useGetAchievements({
    query: { queryKey: getGetAchievementsQueryKey() },
  });

  const earned = data?.badges.filter((b) => b.earned) ?? [];
  const locked = data?.badges.filter((b) => !b.earned) ?? [];

  return (
    <AppLayout>
      <div className="container mx-auto p-4 lg:p-8 flex-1 flex flex-col">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white tracking-tight mb-1">Achievement Badges</h1>
          <p className="text-sm text-muted-foreground font-mono">
            {isLoading ? "Loading..." : `${data?.totalEarned ?? 0} / ${data?.badges.length ?? 0} earned`}
          </p>
        </div>

        {/* Progress overview */}
        {!isLoading && data && (
          <div className="bg-card border border-border rounded-xl p-4 mb-6 flex items-center gap-4">
            <div className="flex-1">
              <div className="flex justify-between text-xs font-mono text-muted-foreground mb-2">
                <span>OVERALL PROGRESS</span>
                <span className="text-primary">{data.totalEarned}/{data.badges.length}</span>
              </div>
              <ProgressBar value={(data.totalEarned / data.badges.length) * 100} />
            </div>
            <div className="shrink-0 text-center">
              <div className="text-3xl font-bold text-primary font-mono">
                {Math.round((data.totalEarned / data.badges.length) * 100)}%
              </div>
              <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Complete</div>
            </div>
          </div>
        )}

        {isLoading ? (
          <div className="flex items-center justify-center py-24">
            <div className="text-xs font-mono text-muted-foreground uppercase tracking-widest animate-pulse">Loading badges…</div>
          </div>
        ) : (
          <>
            {/* Earned badges */}
            {earned.length > 0 && (
              <section className="mb-8">
                <h2 className="text-xs font-mono uppercase tracking-widest text-primary mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-primary inline-block" />
                  Earned — {earned.length}
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                  {earned.map((badge) => (
                    <div
                      key={badge.id}
                      className="bg-card border border-primary/30 rounded-xl p-4 flex items-start gap-3 hover:border-primary/60 transition-colors relative overflow-hidden"
                    >
                      {/* Glow effect */}
                      <div className="absolute inset-0 bg-primary/5 pointer-events-none" />
                      <div className="text-3xl shrink-0">{badge.icon}</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm text-white leading-snug">{badge.title}</div>
                        <div className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{badge.description}</div>
                        {badge.earnedAt && (
                          <div className="text-[10px] font-mono text-primary/70 mt-1.5">
                            ✓ {new Date(badge.earnedAt).toLocaleDateString()}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Locked badges */}
            {locked.length > 0 && (
              <section>
                <h2 className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-muted-foreground inline-block" />
                  Locked — {locked.length}
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                  {locked.map((badge) => (
                    <div
                      key={badge.id}
                      className="bg-card border border-border rounded-xl p-4 flex items-start gap-3 opacity-60"
                    >
                      <div className="text-3xl shrink-0 grayscale">{badge.icon}</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm text-slate-400 leading-snug">{badge.title}</div>
                        <div className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{badge.description}</div>
                        {badge.progress != null && (
                          <div className="mt-2">
                            <div className="flex justify-between text-[10px] font-mono text-muted-foreground mb-1">
                              <span>Progress</span>
                              <span>{Math.round(badge.progress)}%{badge.target ? ` (of ${badge.target})` : ""}</span>
                            </div>
                            <ProgressBar value={badge.progress} />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {!earned.length && !locked.length && (
              <div className="text-center text-muted-foreground py-16 font-mono text-sm">
                No badges found. Start logging trades to earn achievements!
              </div>
            )}
          </>
        )}
      </div>
    </AppLayout>
  );
}
