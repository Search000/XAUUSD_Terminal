import { useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import { useActivateLicense, getGetLicenseStatusQueryKey } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useUser } from "@clerk/react";
import { useQueryClient } from "@tanstack/react-query";
import { KeyRound, Shield, Activity, Loader2, Phone, Send, CheckCircle2, X } from "lucide-react";

const apiBaseUrl =
  (import.meta.env.VITE_API_URL as string) || "";

export default function ActivatePage() {
  const [code, setCode] = useState("");
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { user } = useUser();
  const queryClient = useQueryClient();
  const email = user?.primaryEmailAddress?.emailAddress ?? "";

  // Contact form state
  const [phone, setPhone] = useState("");
  const [contactLoading, setContactLoading] = useState(false);
  const [contactSent, setContactSent] = useState(false);
  const [limitReached, setLimitReached] = useState(false);
  const [showPopup, setShowPopup] = useState(false);

  const activate = useActivateLicense({
    mutation: {
      onSuccess: async () => {
        toast({
          title: "Access Granted",
          description: "Terminal unlocked successfully.",
          className: "bg-green-500/10 text-green-500 border-green-500/20",
        });
        await queryClient.invalidateQueries({ queryKey: getGetLicenseStatusQueryKey() });
        setLocation("/dashboard");
      },
      onError: (err) => {
        toast({
          title: "Access Denied",
          description: err.message || "Invalid or expired license code.",
          variant: "destructive",
        });
      }
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) return;
    activate.mutate({ data: { licenseCode: code.trim() } });
  };

  const handleContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone.trim() || limitReached || contactLoading) return;

    setContactLoading(true);
    try {
      const res = await fetch(`${apiBaseUrl}/api/contact`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: phone.trim(), email }),
      });

      if (res.status === 429) {
        setLimitReached(true);
        toast({ title: "Blocked", description: "Too many attempts from your IP. Please try later.", variant: "destructive" });
        return;
      }

      if (!res.ok) {
        const data = await res.json() as { error?: string };
        toast({ title: "Error", description: data.error ?? "Something went wrong.", variant: "destructive" });
        return;
      }

      const data = await res.json() as { success: boolean; limitReached?: boolean; attemptsLeft?: number };

      if (data.limitReached) {
        setLimitReached(true);
        toast({ title: "Limit Reached", description: "You've already sent the maximum number of requests.", variant: "destructive" });
        return;
      }

      setContactSent(true);
      setPhone("");
      setShowPopup(true);
    } catch {
      toast({ title: "Error", description: "Could not send request. Try again.", variant: "destructive" });
    } finally {
      setContactLoading(false);
    }
  };

  const blocked = limitReached;

  return (
    <AppLayout hideNav>
      <div className="flex-1 flex items-center justify-center p-4 relative overflow-hidden">
        {/* Decorative background grid */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

        <div className="w-full max-w-md relative z-10 space-y-4">
          {/* User email pill */}
          {email && (
            <div className="text-center">
              <span className="inline-block bg-secondary/60 border border-border rounded-full px-4 py-1.5 text-xs font-mono text-slate-300 tracking-wide">
                {email}
              </span>
            </div>
          )}

          {/* ── License Card ── */}
          <div className="p-6 bg-card border border-border rounded-lg shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-6">
              <Shield className="w-6 h-6" />
            </div>

            <div className="text-center mb-8">
              <h1 className="text-lg font-bold text-white mb-2">Initialize Terminal</h1>
              <p className="text-muted-foreground text-sm">Enter your provisioning code to grant access.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <div className="relative">
                  <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <input
                    type="text"
                    placeholder="XXXX-XXXX-XXXX"
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    className="w-full bg-input border border-border rounded py-3 pl-10 pr-4 text-white font-mono uppercase tracking-widest focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent placeholder:text-muted-foreground/50 placeholder:normal-case placeholder:tracking-normal"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={activate.isPending || !code.trim()}
                className="w-full bg-primary text-black font-semibold rounded py-3 hover:bg-amber-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {activate.isPending ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Verifying...
                  </>
                ) : (
                  <>
                    <Activity className="w-5 h-5" />
                    Authenticate
                  </>
                )}
              </button>
            </form>

            <div className="mt-8 pt-6 border-t border-border text-center">
              <p className="text-xs text-muted-foreground">
                Don't have a code? Contact your administrator or purchase a license to continue.
              </p>
            </div>
          </div>

          {/* ── Contact / License Request Card ── */}
          <div className="p-6 bg-card border border-border rounded-lg shadow-xl">
            <div className="flex items-center gap-2 mb-4">
              <Phone className="w-4 h-4 text-primary" />
              <h2 className="text-sm font-bold text-white font-mono uppercase tracking-widest">Request a License</h2>
            </div>
            <p className="text-xs text-muted-foreground mb-4 leading-relaxed">
              Leave your phone number and we'll get back to you on Telegram.
            </p>

            <form onSubmit={handleContact} className="space-y-3">
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="tel"
                  placeholder="+880 1700 000000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  disabled={blocked || contactSent}
                  className="w-full bg-input border border-border rounded py-2.5 pl-9 pr-4 text-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent placeholder:text-muted-foreground/50 disabled:opacity-40 disabled:cursor-not-allowed"
                />
              </div>
              <button
                type="submit"
                disabled={contactLoading || !phone.trim() || blocked || contactSent}
                className="w-full bg-primary/10 border border-primary/30 text-primary font-semibold rounded py-2.5 hover:bg-primary/20 transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm"
              >
                {contactLoading ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Sending...</>
                ) : contactSent ? (
                  <><CheckCircle2 className="w-4 h-4" /> Request Sent</>
                ) : (
                  <><Send className="w-4 h-4" /> Send Request</>
                )}
              </button>
              {blocked && !contactSent && (
                <p className="text-center text-xs text-muted-foreground font-mono">
                  You've already sent the maximum number of requests.
                </p>
              )}
            </form>
          </div>
        </div>
      </div>

      {/* ── Success Popup ── */}
      {showPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowPopup(false)}
          />

          {/* Modal */}
          <div className="relative w-full max-w-sm bg-card border border-border rounded-2xl shadow-2xl p-6 flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-200">
            {/* Close */}
            <button
              onClick={() => setShowPopup(false)}
              className="absolute top-4 right-4 text-muted-foreground hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Icon */}
            <div className="w-16 h-16 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center mb-5">
              <CheckCircle2 className="w-8 h-8 text-green-400" />
            </div>

            {/* Title */}
            <h2 className="text-xl font-bold text-white mb-2">Request Sent!</h2>

            {/* Body */}
            <p className="text-sm text-muted-foreground leading-relaxed mb-6">
              Your phone number has been received.<br />
              We'll reach out to you on <span className="text-primary font-semibold">Telegram</span> shortly.
            </p>

            {/* Telegram badge */}
            <div className="flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-lg px-4 py-2.5 mb-6">
              <svg className="w-5 h-5 text-primary shrink-0" viewBox="0 0 24 24" fill="currentColor">
                <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
              </svg>
              <span className="text-sm text-primary font-mono font-semibold">Reply via Telegram</span>
            </div>

            <button
              onClick={() => setShowPopup(false)}
              className="w-full bg-primary text-black font-semibold rounded-lg py-2.5 hover:bg-amber-400 transition-colors text-sm"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </AppLayout>
  );
}
