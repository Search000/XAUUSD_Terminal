import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db } from "@workspace/db";
import { licensesTable, usersTable, systemSettingsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, requireAdmin, upsertUser } from "../lib/auth";
import { randomBytes } from "crypto";

const router = Router();

/** Generate a cryptographically random license code */
function generateCode(): string {
  const part1 = randomBytes(4).toString("hex").toUpperCase();
  const part2 = randomBytes(4).toString("hex").toUpperCase();
  const part3 = randomBytes(4).toString("hex").toUpperCase();
  return `${part1}-${part2}-${part3}`;
}

/** POST /api/licenses/generate — Admin only */
router.post("/licenses/generate", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const { transactionCode, durationDays, note } = req.body as {
    transactionCode: string;
    durationDays: number;
    note?: string;
  };

  if (!transactionCode || !durationDays) {
    res.status(400).json({ error: "transactionCode and durationDays are required" });
    return;
  }

  const licenseCode = generateCode();
  const [license] = await db
    .insert(licensesTable)
    .values({
      licenseCode,
      transactionCode: transactionCode.trim().toUpperCase(),
      durationDays: Number(durationDays),
      note: note ?? null,
      isActive: false,
      isRevoked: false,
    })
    .returning();

  res.status(201).json(serializeLicense(license));
});

/** POST /api/licenses/activate — Authenticated user */
router.post("/licenses/activate", requireAuth, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  try {
    await upsertUser(userId);

    const { licenseCode } = req.body as { licenseCode: string };
    if (!licenseCode) {
      res.status(400).json({ error: "licenseCode is required" });
      return;
    }

    const [license] = await db
      .select()
      .from(licensesTable)
      .where(eq(licensesTable.licenseCode, licenseCode.trim().toUpperCase()));

    if (!license) {
      res.status(400).json({ error: "Invalid license code" });
      return;
    }
    if (license.isRevoked) {
      res.status(400).json({ error: "This license has been revoked" });
      return;
    }
    if (license.isActive && license.usedByUserId && license.usedByUserId !== userId) {
      res.status(400).json({ error: "This license is already in use" });
      return;
    }

    const now = new Date();
    const expiresAt = new Date(now.getTime() + license.durationDays * 24 * 60 * 60 * 1000);

    // Get email from DB (upserted above — may still be empty if Clerk unreachable)
    const [userRow] = await db.select().from(usersTable).where(eq(usersTable.userId, userId));

    await db
      .update(licensesTable)
      .set({
        isActive: true,
        activatedAt: now,
        expiresAt,
        usedByUserId: userId,
        usedByEmail: userRow?.email ?? "",
      })
      .where(eq(licensesTable.id, license.id));

    const daysRemaining = Math.ceil((expiresAt.getTime() - now.getTime()) / (24 * 60 * 60 * 1000));
    const [systemSettings] = await db
      .select()
      .from(systemSettingsTable)
      .where(eq(systemSettingsTable.id, 1));

    res.json({
      hasLicense: true,
      isActive: true,
      expiresAt: expiresAt.toISOString(),
      daysRemaining,
      licenseEnforcementEnabled: systemSettings?.licenseEnforcementEnabled ?? true,
    });
  } catch (err) {
    req.log.error({ err }, "License activation failed");
    res.status(500).json({ error: "License activation failed. Please try again." });
  }
});

/** GET /api/licenses/status */
router.get("/licenses/status", requireAuth, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [systemSettings] = await db
    .select()
    .from(systemSettingsTable)
    .where(eq(systemSettingsTable.id, 1));
  const licenseEnforcementEnabled = systemSettings?.licenseEnforcementEnabled ?? true;

  const now = new Date();
  const [license] = await db
    .select()
    .from(licensesTable)
    .where(and(eq(licensesTable.usedByUserId, userId), eq(licensesTable.isActive, true)));

  if (!license || license.isRevoked) {
    res.json({
      hasLicense: false,
      isActive: false,
      expiresAt: null,
      daysRemaining: null,
      licenseEnforcementEnabled,
    });
    return;
  }

  const expired = license.expiresAt && license.expiresAt < now;
  const daysRemaining = license.expiresAt
    ? Math.max(0, Math.ceil((license.expiresAt.getTime() - now.getTime()) / (24 * 60 * 60 * 1000)))
    : null;

  res.json({
    hasLicense: true,
    isActive: !expired,
    expiresAt: license.expiresAt?.toISOString() ?? null,
    daysRemaining,
    licenseEnforcementEnabled,
  });
});

/** GET /api/licenses — Admin only */
router.get("/licenses", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const licenses = await db.select().from(licensesTable).orderBy(licensesTable.createdAt);
  res.json(licenses.map(serializeLicense));
});

/** PATCH /api/licenses/:id/revoke — Admin only */
router.patch("/licenses/:id/revoke", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid license ID" }); return; }
  const [updated] = await db
    .update(licensesTable)
    .set({ isRevoked: true, isActive: false })
    .where(eq(licensesTable.id, id))
    .returning();
  if (!updated) { res.status(404).json({ error: "License not found" }); return; }
  res.json(serializeLicense(updated));
});

/** DELETE /api/licenses/:id — Admin only, permanently delete any license */
router.delete("/licenses/:id", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid license ID" }); return; }
  const [deleted] = await db
    .delete(licensesTable)
    .where(eq(licensesTable.id, id))
    .returning({ id: licensesTable.id });

  if (!deleted) { res.status(404).json({ error: "License not found" }); return; }
  res.status(204).send();
});

function serializeLicense(l: typeof licensesTable.$inferSelect) {
  return {
    id: l.id,
    licenseCode: l.licenseCode,
    transactionCode: l.transactionCode,
    durationDays: l.durationDays,
    activatedAt: l.activatedAt?.toISOString() ?? null,
    expiresAt: l.expiresAt?.toISOString() ?? null,
    isActive: l.isActive,
    isRevoked: l.isRevoked,
    usedByUserId: l.usedByUserId ?? null,
    usedByEmail: l.usedByEmail ?? null,
    note: l.note ?? null,
    createdAt: l.createdAt.toISOString(),
  };
}

export default router;
