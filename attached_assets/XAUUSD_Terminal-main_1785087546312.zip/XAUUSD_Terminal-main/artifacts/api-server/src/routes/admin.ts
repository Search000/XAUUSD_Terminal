import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, licensesTable, tradesTable, investorsTable, systemSettingsTable, notificationsTable } from "@workspace/db";
import { eq, and, count, sum, desc, or } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../lib/auth";

const router = Router();

/** GET /api/admin/users */
router.get("/admin/users", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const users = await db.select().from(usersTable).orderBy(usersTable.createdAt);
  const now = new Date();

  const result = await Promise.all(
    users.map(async (user) => {
      const [
        [license],
        tradeCount,
        [latestTrade],
        [investor],
        investmentSum,
      ] = await Promise.all([
        db.select().from(licensesTable)
          .where(and(eq(licensesTable.usedByUserId, user.userId), eq(licensesTable.isActive, true))),
        db.select({ count: count() }).from(tradesTable).where(eq(tradesTable.userId, user.userId)),
        db.select({ balance: tradesTable.balance }).from(tradesTable)
          .where(eq(tradesTable.userId, user.userId))
          .orderBy(desc(tradesTable.id)).limit(1),
        db.select().from(investorsTable)
          .where(eq(investorsTable.userId, user.userId))
          .orderBy(investorsTable.createdAt).limit(1),
        db.select({ total: sum(investorsTable.investmentAmount) }).from(investorsTable)
          .where(eq(investorsTable.userId, user.userId)),
      ]);

      let isLicenseActive = false;
      let licenseExpiresAt: string | null = null;
      let daysRemaining: number | null = null;

      if (license && !license.isRevoked) {
        const expired = license.expiresAt && license.expiresAt < now;
        isLicenseActive = !expired;
        licenseExpiresAt = license.expiresAt?.toISOString() ?? null;
        daysRemaining = license.expiresAt
          ? Math.max(0, Math.ceil((license.expiresAt.getTime() - now.getTime()) / (24 * 60 * 60 * 1000)))
          : null;
      }

      return {
        userId: user.userId,
        email: user.email,
        createdAt: user.createdAt.toISOString(),
        lastLoginAt: user.lastLoginAt?.toISOString() ?? null,
        hasLicense: !!license,
        isLicenseActive,
        licenseExpiresAt,
        daysRemaining,
        totalTrades: tradeCount[0]?.count ?? 0,
        licenseCode: license?.licenseCode ?? null,
        licenseTransactionCode: license?.transactionCode ?? null,
        licenseDurationDays: license?.durationDays ?? null,
        investorName: investor?.name ?? null,
        latestBalance: latestTrade?.balance ?? null,
        totalInvestment: investmentSum[0]?.total ?? null,
      };
    }),
  );

  res.json(result);
});

/** GET /api/admin/stats */
router.get("/admin/stats", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const now = new Date();
  const [totalUsers] = await db.select({ count: count() }).from(usersTable);
  const allLicenses = await db.select().from(licensesTable);

  const activeLicenses = allLicenses.filter(
    (l) => l.isActive && !l.isRevoked && (!l.expiresAt || l.expiresAt > now),
  ).length;
  const expiredLicenses = allLicenses.filter(
    (l) => l.isActive && !l.isRevoked && l.expiresAt && l.expiresAt <= now,
  ).length;
  const revokedLicenses = allLicenses.filter((l) => l.isRevoked).length;

  // Active users = those with at least one trade
  const activeUserRows = await db
    .select({ userId: tradesTable.userId })
    .from(tradesTable)
    .groupBy(tradesTable.userId);

  res.json({
    totalUsers: totalUsers.count,
    activeUsers: activeUserRows.length,
    totalLicenses: allLicenses.length,
    activeLicenses,
    expiredLicenses,
    revokedLicenses,
  });
});

/** GET /api/admin/system-settings */
router.get("/admin/system-settings", requireAuth, requireAdmin, async (_req, res): Promise<void> => {
  const [row] = await db.select().from(systemSettingsTable).where(eq(systemSettingsTable.id, 1));
  res.json({
    licenseEnforcementEnabled: row?.licenseEnforcementEnabled ?? true,
  });
});

/** PUT /api/admin/system-settings */
router.put("/admin/system-settings", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const { licenseEnforcementEnabled } = req.body as { licenseEnforcementEnabled: boolean };
  if (typeof licenseEnforcementEnabled !== "boolean") {
    res.status(400).json({ error: "licenseEnforcementEnabled must be a boolean" });
    return;
  }

  const [updated] = await db
    .update(systemSettingsTable)
    .set({ licenseEnforcementEnabled, updatedAt: new Date() })
    .where(eq(systemSettingsTable.id, 1))
    .returning();

  if (updated) {
    res.json({ licenseEnforcementEnabled: updated.licenseEnforcementEnabled });
    return;
  }

  const [created] = await db
    .insert(systemSettingsTable)
    .values({ id: 1, licenseEnforcementEnabled })
    .returning();
  res.json({ licenseEnforcementEnabled: created.licenseEnforcementEnabled });
});

/** POST /api/admin/notifications/broadcast
 *  Send an in-app notification to all users (stored as userId = "__admin__").
 */
router.post("/admin/notifications/broadcast", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const { title, body } = req.body as { title?: string; body?: string };
  if (!title || !body) {
    res.status(400).json({ error: "title and body are required" });
    return;
  }

  const [row] = await db
    .insert(notificationsTable)
    .values({ userId: "__admin__", type: "admin", title, body, isRead: false })
    .returning();

  // Push instant SSE event to every connected user
  const { pushNotificationSSE } = await import("../lib/sseClients");
  pushNotificationSSE("__admin__");

  res.status(201).json(row);
});

/** GET /api/admin/notifications — list recent broadcasts AND targeted sends */
router.get("/admin/notifications", requireAuth, requireAdmin, async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(notificationsTable)
    .where(or(
      eq(notificationsTable.userId, "__admin__"),
      eq(notificationsTable.userId, "__targeted__"),
    ))
    .orderBy(desc(notificationsTable.createdAt))
    .limit(100);
  res.json(rows);
});

/** DELETE /api/admin/notifications/:id — delete notification from admin history AND from all customers */
router.delete("/admin/notifications/:id", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  // Fetch the record first so we know what to cascade-delete
  const [record] = await db
    .select()
    .from(notificationsTable)
    .where(and(
      eq(notificationsTable.id, id),
      or(eq(notificationsTable.userId, "__admin__"), eq(notificationsTable.userId, "__targeted__")),
    ));

  if (!record) { res.status(404).json({ error: "Not found" }); return; }

  if (record.userId === "__targeted__") {
    // Delete the tracking record + all matching user copies (same title + body + type admin)
    await db
      .delete(notificationsTable)
      .where(and(
        eq(notificationsTable.title, record.title),
        eq(notificationsTable.body, record.body),
        eq(notificationsTable.type, "admin"),
      ));
  }

  // Delete the admin/tracking record itself
  await db.delete(notificationsTable).where(eq(notificationsTable.id, id));

  res.json({ success: true });
});

/** DELETE /api/admin/notifications — clear ALL admin history AND all customer admin notifications */
router.delete("/admin/notifications", requireAuth, requireAdmin, async (_req, res): Promise<void> => {
  // Delete all customer-side admin notifications (targeted or broadcast)
  await db
    .delete(notificationsTable)
    .where(eq(notificationsTable.type, "admin"));

  // Also delete any leftover __targeted__ tracking records
  const deleted = await db
    .delete(notificationsTable)
    .where(or(
      eq(notificationsTable.userId, "__admin__"),
      eq(notificationsTable.userId, "__targeted__"),
    ))
    .returning();

  res.json({ deleted: deleted.length });
});

/** POST /api/admin/notifications/send-to-users — targeted notification to specific users */
router.post("/admin/notifications/send-to-users", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const { title, body, userIds } = req.body as { title?: string; body?: string; userIds?: string[] };

  if (!title || !body) { res.status(400).json({ error: "title and body are required" }); return; }
  if (!Array.isArray(userIds) || userIds.length === 0) {
    res.status(400).json({ error: "userIds must be a non-empty array" }); return;
  }

  const { pushNotificationSSE } = await import("../lib/sseClients");

  const inserts = await Promise.all(
    userIds.map(async (userId) => {
      const [row] = await db
        .insert(notificationsTable)
        .values({ userId, type: "admin", title, body, isRead: false })
        .returning();
      pushNotificationSSE(userId);
      return row;
    }),
  );

  // Save a tracking record so the admin history shows this targeted send
  await db.insert(notificationsTable).values({
    userId: "__targeted__",
    type: "admin_targeted",
    title,
    body,
    isRead: false,
  });

  res.status(201).json({ sent: inserts.length });
});

export default router;
