import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db } from "@workspace/db";
import { tradesTable } from "@workspace/db";
import { eq, and, gte, lte, desc } from "drizzle-orm";
import { requireAuth } from "../lib/auth";
import { requireLicense } from "../lib/licenseCheck";
import { sendRiskAlertIfNeeded } from "../lib/notifications";

const router = Router();

/** GET /api/trades */
router.get("/trades", requireAuth, requireLicense, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const { limit = "100", offset = "0", startDate, endDate } = req.query as Record<string, string>;

  const conditions = [eq(tradesTable.userId, userId)];
  if (startDate) conditions.push(gte(tradesTable.tradeDate, startDate));
  if (endDate) conditions.push(lte(tradesTable.tradeDate, endDate));

  const trades = await db
    .select()
    .from(tradesTable)
    .where(and(...conditions))
    .orderBy(desc(tradesTable.tradeDate), desc(tradesTable.createdAt))
    .limit(parseInt(limit, 10))
    .offset(parseInt(offset, 10));

  res.json(trades.map(serializeTrade));
});

/** POST /api/trades */
router.post("/trades", requireAuth, requireLicense, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const body = req.body as {
    tradeDate: string;
    direction: string;
    status?: string;
    balance?: number | null;
    riskPct?: number | null;
    entryPrice?: number | null;
    slPrice?: number | null;
    tpPrice?: number | null;
    lotSize?: number | null;
    closePrice?: number | null;
    pips?: number | null;
    pnl?: number | null;
    tags?: string | null;
    session?: string | null;
    notes?: string | null;
    screenshotUrl?: string | null;
    lossReason?: string | null;
  };

  if (!body.tradeDate || !body.direction) {
    res.status(400).json({ error: "tradeDate and direction are required" });
    return;
  }

  const [trade] = await db
    .insert(tradesTable)
    .values({
      userId,
      tradeDate: body.tradeDate,
      direction: body.direction,
      status: body.status ?? "Pending",
      balance: body.balance != null ? String(body.balance) : null,
      riskPct: body.riskPct != null ? String(body.riskPct) : null,
      entryPrice: body.entryPrice != null ? String(body.entryPrice) : null,
      slPrice: body.slPrice != null ? String(body.slPrice) : null,
      tpPrice: body.tpPrice != null ? String(body.tpPrice) : null,
      lotSize: body.lotSize != null ? String(body.lotSize) : null,
      closePrice: body.closePrice != null ? String(body.closePrice) : null,
      pips: body.pips != null ? String(body.pips) : null,
      pnl: body.pnl != null ? String(body.pnl) : null,
      tags: body.tags ?? null,
      session: body.session ?? null,
      notes: body.notes ?? null,
      screenshotUrl: body.screenshotUrl ?? null,
      lossReason: body.lossReason ?? null,
    })
    .returning();

  // Fire risk alert in background if trade is already closed
  if (trade.status === "TP Hit" || trade.status === "SL Hit") {
    sendRiskAlertIfNeeded(userId, trade.id).catch(() => {});
  }

  res.status(201).json(serializeTrade(trade));
});

/** PATCH /api/trades/:id */
router.patch("/trades/:id", requireAuth, requireLicense, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid trade ID" }); return; }

  const body = req.body as {
    direction?: string;
    status?: string;
    notes?: string | null;
    balance?: number | null;
    riskPct?: number | null;
    entryPrice?: number | null;
    slPrice?: number | null;
    tpPrice?: number | null;
    lotSize?: number | null;
    closePrice?: number | null;
    pips?: number | null;
    pnl?: number | null;
    tags?: string | null;
    session?: string | null;
    lossReason?: string | null;
  };

  const updateData: Partial<typeof tradesTable.$inferInsert> = {};
  if ("direction" in body) updateData.direction = body.direction;
  if ("status" in body) updateData.status = body.status ?? "Pending";
  if ("notes" in body) updateData.notes = body.notes;
  if ("balance" in body) updateData.balance = body.balance != null ? String(body.balance) : null;
  if ("riskPct" in body) updateData.riskPct = body.riskPct != null ? String(body.riskPct) : null;
  if ("entryPrice" in body) updateData.entryPrice = body.entryPrice != null ? String(body.entryPrice) : null;
  if ("slPrice" in body) updateData.slPrice = body.slPrice != null ? String(body.slPrice) : null;
  if ("tpPrice" in body) updateData.tpPrice = body.tpPrice != null ? String(body.tpPrice) : null;
  if ("lotSize" in body) updateData.lotSize = body.lotSize != null ? String(body.lotSize) : null;
  if ("closePrice" in body) updateData.closePrice = body.closePrice != null ? String(body.closePrice) : null;
  if ("pips" in body) updateData.pips = body.pips != null ? String(body.pips) : null;
  if ("pnl" in body) updateData.pnl = body.pnl != null ? String(body.pnl) : null;
  if ("tags" in body) updateData.tags = body.tags;
  if ("session" in body) updateData.session = body.session;
  if ("screenshotUrl" in body) updateData.screenshotUrl = body.screenshotUrl as string | null | undefined;
  if ("lossReason" in body) updateData.lossReason = body.lossReason;

  const [updated] = await db
    .update(tradesTable)
    .set(updateData)
    .where(and(eq(tradesTable.id, id), eq(tradesTable.userId, userId)))
    .returning();

  if (!updated) { res.status(404).json({ error: "Trade not found" }); return; }

  // Fire risk alert in background when a trade is closed via update
  if (updated.status === "TP Hit" || updated.status === "SL Hit") {
    sendRiskAlertIfNeeded(userId, updated.id).catch(() => {});
  }

  res.json(serializeTrade(updated));
});

/** DELETE /api/trades/:id */
router.delete("/trades/:id", requireAuth, requireLicense, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid trade ID" }); return; }

  await db.delete(tradesTable).where(and(eq(tradesTable.id, id), eq(tradesTable.userId, userId)));
  res.json({ success: true });
});

function serializeTrade(t: typeof tradesTable.$inferSelect) {
  return {
    id: t.id,
    userId: t.userId,
    tradeDate: t.tradeDate,
    balance: t.balance != null ? parseFloat(t.balance) : null,
    riskPct: t.riskPct != null ? parseFloat(t.riskPct) : null,
    entryPrice: t.entryPrice != null ? parseFloat(t.entryPrice) : null,
    slPrice: t.slPrice != null ? parseFloat(t.slPrice) : null,
    tpPrice: t.tpPrice != null ? parseFloat(t.tpPrice) : null,
    lotSize: t.lotSize != null ? parseFloat(t.lotSize) : null,
    direction: t.direction,
    status: t.status,
    closePrice: t.closePrice != null ? parseFloat(t.closePrice) : null,
    pips: t.pips != null ? parseFloat(t.pips) : null,
    pnl: t.pnl != null ? parseFloat(t.pnl) : null,
    tags: t.tags,
    session: t.session,
    notes: t.notes,
    screenshotUrl: t.screenshotUrl,
    lossReason: t.lossReason,
    createdAt: t.createdAt.toISOString(),
  };
}

export default router;
