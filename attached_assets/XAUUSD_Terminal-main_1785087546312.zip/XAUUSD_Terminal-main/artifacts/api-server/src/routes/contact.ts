import { Router } from "express";
import { db } from "@workspace/db";
import { telegramSettingsTable, contactAttemptsTable, contactConfigTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { sendTelegramMessage } from "../lib/telegram";
import { requireAuth, requireAdmin } from "../lib/auth";

const router = Router();

/** Get global limit from DB (fallback = 3) */
async function getLimit(): Promise<number> {
  const [cfg] = await db.select().from(contactConfigTable).where(eq(contactConfigTable.id, 1));
  return cfg?.limit ?? 3;
}

/**
 * POST /api/contact  — public
 * Body: { phone: string, email?: string }
 */
router.post("/contact", async (req, res): Promise<void> => {
  const { phone, email } = req.body as { phone?: string; email?: string };

  if (!phone?.trim()) {
    res.status(400).json({ error: "Phone number is required." });
    return;
  }

  // Determine client IP
  const forwarded = req.headers["x-forwarded-for"];
  const ip = (forwarded
    ? (Array.isArray(forwarded) ? forwarded[0] : forwarded).split(",")[0].trim()
    : req.socket.remoteAddress) ?? "unknown";

  const limit = await getLimit();

  // Upsert attempt row
  const [existing] = await db.select().from(contactAttemptsTable).where(eq(contactAttemptsTable.ip, ip));

  let newCount: number;
  if (existing) {
    newCount = existing.attempts + 1;
    await db.update(contactAttemptsTable)
      .set({ attempts: newCount, lastEmail: email ?? existing.lastEmail, lastPhone: phone.trim(), lastAt: new Date() })
      .where(eq(contactAttemptsTable.ip, ip));
  } else {
    newCount = 1;
    await db.insert(contactAttemptsTable).values({ ip, attempts: 1, lastEmail: email ?? null, lastPhone: phone.trim() });
  }

  // Silently reject if over limit (client already disabled the form, this is extra safety)
  if ((existing?.attempts ?? 0) >= limit) {
    res.json({ success: false, limitReached: true });
    return;
  }

  // Send Telegram notification — always to the admin's configured bot, never any other signed-up user's
  const [settings] = await db
    .select({
      botToken: telegramSettingsTable.botToken,
      chatId: telegramSettingsTable.chatId,
      groupId: telegramSettingsTable.groupId,
    })
    .from(telegramSettingsTable)
    .innerJoin(usersTable, eq(usersTable.userId, telegramSettingsTable.userId))
    .where(eq(usersTable.isAdmin, true))
    .limit(1);
  if (settings?.botToken && settings?.chatId) {
    const text =
      `📞 *License Request*\n\n` +
      `👤 Email: \`${email ?? "Not provided"}\`\n` +
      `📱 Phone: \`${phone.trim()}\`\n` +
      `🌐 IP: \`${ip}\`\n` +
      `🔢 Attempt #${newCount} / ${limit}`;
    try {
      await sendTelegramMessage(settings.botToken, settings.chatId, text);
      if (settings.groupId) await sendTelegramMessage(settings.botToken, settings.groupId, text).catch(() => {});
    } catch { /* silent */ }
  }

  res.json({ success: true, attemptsLeft: Math.max(0, limit - newCount) });
});

// ─── Admin routes ────────────────────────────────────────────────────────────

/** GET /api/admin/contact-attempts — list all IPs with attempt counts */
router.get("/admin/contact-attempts", requireAuth, requireAdmin, async (_req, res): Promise<void> => {
  const rows = await db.select().from(contactAttemptsTable).orderBy(contactAttemptsTable.lastAt);
  const limit = await getLimit();
  res.json({ limit, rows });
});

/** GET /api/admin/contact-config — get current limit */
router.get("/admin/contact-config", requireAuth, requireAdmin, async (_req, res): Promise<void> => {
  const limit = await getLimit();
  res.json({ limit });
});

/** PUT /api/admin/contact-config — set new limit */
router.put("/admin/contact-config", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const { limit } = req.body as { limit?: number };
  if (!limit || limit < 1) { res.status(400).json({ error: "limit must be >= 1" }); return; }

  const [existing] = await db.select().from(contactConfigTable).where(eq(contactConfigTable.id, 1));
  if (existing) {
    await db.update(contactConfigTable).set({ limit }).where(eq(contactConfigTable.id, 1));
  } else {
    await db.insert(contactConfigTable).values({ id: 1, limit });
  }
  res.json({ limit });
});

/** DELETE /api/admin/contact-attempts/:ip — reset a specific IP */
router.delete("/admin/contact-attempts/:ip", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const ip = decodeURIComponent(String(req.params.ip));
  await db.delete(contactAttemptsTable).where(eq(contactAttemptsTable.ip, ip));
  res.json({ success: true });
});

/** DELETE /api/admin/contact-attempts — reset ALL IPs */
router.delete("/admin/contact-attempts", requireAuth, requireAdmin, async (_req, res): Promise<void> => {
  await db.delete(contactAttemptsTable);
  res.json({ success: true });
});

export default router;
