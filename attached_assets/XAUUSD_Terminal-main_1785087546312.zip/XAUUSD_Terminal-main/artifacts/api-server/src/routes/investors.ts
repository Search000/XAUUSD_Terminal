import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db } from "@workspace/db";
import { investorsTable, tradesTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import { requireAuth } from "../lib/auth";
import { requireLicense } from "../lib/licenseCheck";

const router = Router();

/** GET /api/investors */
router.get("/investors", requireAuth, requireLicense, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const investors = await db.select().from(investorsTable).where(eq(investorsTable.userId, userId)).orderBy(desc(investorsTable.investmentAmount));
  res.json(investors.map(serializeInvestor));
});

/** POST /api/investors */
router.post("/investors", requireAuth, requireLicense, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const { name, investmentAmount } = req.body as { name: string; investmentAmount: number };
  if (!name || investmentAmount == null) {
    res.status(400).json({ error: "name and investmentAmount are required" });
    return;
  }

  const [investor] = await db
    .insert(investorsTable)
    .values({ userId, name, investmentAmount: String(investmentAmount) })
    .returning();

  res.status(201).json(serializeInvestor(investor));
});

/** GET /api/investors/shares */
router.get("/investors/shares", requireAuth, requireLicense, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const investors = await db.select().from(investorsTable).where(eq(investorsTable.userId, userId)).orderBy(desc(investorsTable.investmentAmount));

  const allTrades = await db.select().from(tradesTable).where(eq(tradesTable.userId, userId)).orderBy(desc(tradesTable.id));

  const totalInvestment = investors.reduce((s, inv) => s + parseFloat(inv.investmentAmount), 0);

  // Live P&L = sum of all closed-trade pnl fields (TP Hit or SL Hit).
  // This updates automatically as trades close, regardless of whether the
  // user fills in the account balance field on each trade.
  const closedTrades = allTrades.filter(
    (t) => t.status === "TP Hit" || t.status === "SL Hit",
  );
  const totalPnL = closedTrades.reduce(
    (s, t) => s + (t.pnl ? parseFloat(t.pnl) : 0),
    0,
  );
  const currentBalance = totalInvestment + totalPnL;

  const enrichedInvestors = investors.map((inv) => {
    const amount = parseFloat(inv.investmentAmount);
    // Store/display this as a percentage (not a decimal fraction):
    // equal investors therefore receive 100%, 50%, 25%, etc.
    const sharePct = totalInvestment > 0 ? (amount / totalInvestment) * 100 : 0;
    const pnlShare = (sharePct / 100) * totalPnL;
    const totalBal = amount + pnlShare;
    const growthPct = amount > 0 ? (pnlShare / amount) * 100 : 0;
    return {
      id: inv.id,
      name: inv.name,
      investmentAmount: amount,
      createdAt: inv.createdAt.toISOString(),
      sharePct: parseFloat(sharePct.toFixed(4)),
      pnlShare: parseFloat(pnlShare.toFixed(2)),
      totalBalance: parseFloat(totalBal.toFixed(2)),
      growthPct: parseFloat(growthPct.toFixed(4)),
    };
  });

  res.json({
    totalInvestment: parseFloat(totalInvestment.toFixed(2)),
    currentBalance: parseFloat(currentBalance.toFixed(2)),
    totalPnL: parseFloat(totalPnL.toFixed(2)),
    investors: enrichedInvestors,
  });
});

/** PATCH /api/investors/:id */
router.patch("/investors/:id", requireAuth, requireLicense, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid investor ID" }); return; }
  const { name, investmentAmount } = req.body as { name?: string; investmentAmount?: number };

  const updateData: Partial<typeof investorsTable.$inferInsert> = {};
  if (name != null) updateData.name = name;
  if (investmentAmount != null) updateData.investmentAmount = String(investmentAmount);

  const [updated] = await db
    .update(investorsTable)
    .set(updateData)
    .where(and(eq(investorsTable.id, id), eq(investorsTable.userId, userId)))
    .returning();

  if (!updated) { res.status(404).json({ error: "Investor not found" }); return; }
  res.json(serializeInvestor(updated));
});

/** DELETE /api/investors/:id */
router.delete("/investors/:id", requireAuth, requireLicense, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid investor ID" }); return; }
  await db.delete(investorsTable).where(and(eq(investorsTable.id, id), eq(investorsTable.userId, userId)));
  res.json({ success: true });
});

function serializeInvestor(i: typeof investorsTable.$inferSelect) {
  return {
    id: i.id,
    name: i.name,
    investmentAmount: parseFloat(i.investmentAmount),
    createdAt: i.createdAt.toISOString(),
    sharePct: null as number | null,
    pnlShare: null as number | null,
    totalBalance: null as number | null,
    growthPct: null as number | null,
  };
}

export default router;
