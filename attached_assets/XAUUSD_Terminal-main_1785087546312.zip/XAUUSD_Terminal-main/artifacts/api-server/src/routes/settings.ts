import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db } from "@workspace/db";
import { telegramSettingsTable, accountSettingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../lib/auth";
import { broadcastTelegramMessage } from "../lib/telegram";

const router = Router();

/** GET /api/settings/telegram */
router.get("/settings/telegram", requireAdmin, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [settings] = await db.select().from(telegramSettingsTable).where(eq(telegramSettingsTable.userId, userId));
  if (!settings) {
    // Return defaults
    res.json({
      id: 0,
      // REPLACE with your actual Bot Token from @BotFather on Telegram
      // Example format: 1234567890:AAGzSIEPVuSjyz1j_36ER40BLpR71nJXUl
      botToken: "",
      // Your personal Telegram Chat ID (use @userinfobot to find yours)
      chatId: "",
      // Your Telegram Group ID (starts with -100, e.g. -1001234567890)
      groupId: "",
      dailyEnabled: false,
      weeklyEnabled: false,
      monthlyEnabled: false,
      riskAlertEnabled: false,
      winThresholdPct: 10,
      lossThresholdPct: 6,
    });
    return;
  }

  res.json(serializeTelegramSettings(settings));
});

/** POST /api/settings/telegram/test */
router.post("/settings/telegram/test", requireAdmin, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [settings] = await db.select().from(telegramSettingsTable).where(eq(telegramSettingsTable.userId, userId));

  if (!settings || !settings.botToken || !settings.chatId) {
    res.status(400).json({ error: "Bot token and Chat ID must be saved before testing." });
    return;
  }

  const { botToken, chatId, groupId } = settings;
  const text =
    "✅ *XAUUSD Terminal — Test Connection*\n\n" +
    "Your Telegram notifications are configured correctly and working!" +
    (groupId ? "\n\n_(This message was sent to your Personal Chat and Investor Group)_" : "");

  try {
    await broadcastTelegramMessage(botToken, chatId, groupId, text);
    res.json({ success: true });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Failed to reach Telegram API.";
    res.status(400).json({ error: msg });
  }
});

/** PUT /api/settings/telegram */
router.put("/settings/telegram", requireAdmin, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const body = req.body as {
    botToken?: string;
    chatId?: string;
    groupId?: string;
    dailyEnabled?: boolean;
    weeklyEnabled?: boolean;
    monthlyEnabled?: boolean;
    riskAlertEnabled?: boolean;
    winThresholdPct?: number;
    lossThresholdPct?: number;
  };

  const [existing] = await db.select().from(telegramSettingsTable).where(eq(telegramSettingsTable.userId, userId));

  if (existing) {
    const [updated] = await db
      .update(telegramSettingsTable)
      .set({
        botToken: body.botToken ?? existing.botToken,
        chatId: body.chatId ?? existing.chatId,
        groupId: body.groupId ?? existing.groupId,
        dailyEnabled: body.dailyEnabled ?? existing.dailyEnabled,
        weeklyEnabled: body.weeklyEnabled ?? existing.weeklyEnabled,
        monthlyEnabled: body.monthlyEnabled ?? existing.monthlyEnabled,
        riskAlertEnabled: body.riskAlertEnabled ?? existing.riskAlertEnabled,
        winThresholdPct: body.winThresholdPct != null ? String(body.winThresholdPct) : existing.winThresholdPct,
        lossThresholdPct: body.lossThresholdPct != null ? String(body.lossThresholdPct) : existing.lossThresholdPct,
        updatedAt: new Date(),
      })
      .where(eq(telegramSettingsTable.userId, userId))
      .returning();
    res.json(serializeTelegramSettings(updated));
  } else {
    const [created] = await db
      .insert(telegramSettingsTable)
      .values({
        userId,
        botToken: body.botToken ?? "",
        chatId: body.chatId ?? "",
        groupId: body.groupId ?? "",
        dailyEnabled: body.dailyEnabled ?? false,
        weeklyEnabled: body.weeklyEnabled ?? false,
        monthlyEnabled: body.monthlyEnabled ?? false,
        riskAlertEnabled: body.riskAlertEnabled ?? false,
        winThresholdPct: body.winThresholdPct != null ? String(body.winThresholdPct) : "10",
        lossThresholdPct: body.lossThresholdPct != null ? String(body.lossThresholdPct) : "6",
      })
      .returning();
    res.json(serializeTelegramSettings(created));
  }
});

function serializeAccountSettings(s: typeof accountSettingsTable.$inferSelect) {
  return {
    id: s.id,
    timezone: s.timezone,
    defaultRiskPct: s.defaultRiskPct ? parseFloat(s.defaultRiskPct) : 1,
    dailyTargetPct: s.dailyTargetPct ? parseFloat(s.dailyTargetPct) : 2,
    nickname: s.nickname ?? null,
  };
}

/** GET /api/settings/account */
router.get("/settings/account", requireAuth, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const [settings] = await db.select().from(accountSettingsTable).where(eq(accountSettingsTable.userId, userId));
  if (!settings) {
    res.json({ id: 0, timezone: "GMT+6", defaultRiskPct: 1, dailyTargetPct: 2, nickname: null });
    return;
  }
  res.json(serializeAccountSettings(settings));
});

/** PUT /api/settings/account */
router.put("/settings/account", requireAuth, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const { timezone, defaultRiskPct, dailyTargetPct, nickname } = req.body as {
    timezone?: string;
    defaultRiskPct?: number;
    dailyTargetPct?: number;
    nickname?: string | null;
  };

  const [existing] = await db.select().from(accountSettingsTable).where(eq(accountSettingsTable.userId, userId));

  if (existing) {
    const [updated] = await db
      .update(accountSettingsTable)
      .set({
        timezone: timezone ?? existing.timezone,
        defaultRiskPct: defaultRiskPct != null ? String(defaultRiskPct) : existing.defaultRiskPct,
        dailyTargetPct: dailyTargetPct != null ? String(dailyTargetPct) : existing.dailyTargetPct,
        nickname: nickname !== undefined ? (nickname?.trim() || null) : existing.nickname,
        updatedAt: new Date(),
      })
      .where(eq(accountSettingsTable.userId, userId))
      .returning();
    res.json(serializeAccountSettings(updated));
  } else {
    const [created] = await db
      .insert(accountSettingsTable)
      .values({
        userId,
        timezone: timezone ?? "GMT+6",
        defaultRiskPct: defaultRiskPct != null ? String(defaultRiskPct) : "1",
        dailyTargetPct: dailyTargetPct != null ? String(dailyTargetPct) : "2",
        nickname: nickname?.trim() || null,
      })
      .returning();
    res.json(serializeAccountSettings(created));
  }
});

function serializeTelegramSettings(s: typeof telegramSettingsTable.$inferSelect) {
  return {
    id: s.id,
    botToken: s.botToken,
    chatId: s.chatId,
    groupId: s.groupId,
    dailyEnabled: s.dailyEnabled,
    weeklyEnabled: s.weeklyEnabled,
    monthlyEnabled: s.monthlyEnabled,
    riskAlertEnabled: s.riskAlertEnabled,
    winThresholdPct: s.winThresholdPct ? parseFloat(s.winThresholdPct) : 10,
    lossThresholdPct: s.lossThresholdPct ? parseFloat(s.lossThresholdPct) : 6,
  };
}

export default router;
