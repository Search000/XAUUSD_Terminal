import { Router } from "express";
import healthRouter from "./health";
import licensesRouter from "./licenses";
import tradesRouter from "./trades";
import dashboardRouter from "./dashboard";
import reportsRouter from "./reports";
import investorsRouter from "./investors";
import settingsRouter from "./settings";
import adminRouter from "./admin";
import meRouter from "./me";
import offersRouter from "./offers";
import goldpriceRouter from "./goldprice";
import contactRouter from "./contact";
import notificationsRouter from "./notifications";
import achievementsRouter from "./achievements";
import scoreRouter from "./score";
import mistakesRouter from "./mistakes";

const router = Router();

router.use(healthRouter);
router.use(contactRouter);
router.use(goldpriceRouter);
router.use(meRouter);
router.use(licensesRouter);
router.use(tradesRouter);
router.use(dashboardRouter);
router.use(reportsRouter);
router.use(investorsRouter);
router.use(settingsRouter);
router.use(adminRouter);
router.use(offersRouter);
router.use(notificationsRouter);
router.use(achievementsRouter);
router.use(scoreRouter);
router.use(mistakesRouter);

export default router;
