/**
 * Cron-based auto-notification scheduler.
 *
 * Schedule (all times UTC, default timezone GMT+6):
 *   Daily recap   — every day at 17:00 UTC  = 11:00 PM GMT+6
 *   Weekly report — every Friday at 17:00 UTC
 *   Monthly stmt  — last day of month at 17:00 UTC
 *
 * Risk/drawdown alerts are event-driven (triggered per trade close in trades.ts).
 */

import cron from "node-cron";
import {
  sendDailyRecapToAll,
  sendWeeklyReportToAll,
  sendMonthlyReportToAll,
} from "./notifications";
import { logger } from "./logger";

function isLastDayOfMonth(): boolean {
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  return tomorrow.getMonth() !== now.getMonth();
}

export function startScheduler() {
  // ── Daily recap — every day at 17:00 UTC (11 PM GMT+6) ──────────────────
  cron.schedule("0 17 * * *", async () => {
    logger.info("[scheduler] running daily recap");
    await sendDailyRecapToAll().catch((e: unknown) =>
      logger.error({ err: e }, "[scheduler] daily recap error"),
    );
  });

  // ── Weekly report — every Friday at 17:00 UTC ────────────────────────────
  cron.schedule("0 17 * * 5", async () => {
    logger.info("[scheduler] running weekly report");
    await sendWeeklyReportToAll().catch((e: unknown) =>
      logger.error({ err: e }, "[scheduler] weekly report error"),
    );
  });

  // ── Monthly statement — last calendar day at 17:00 UTC ──────────────────
  cron.schedule("0 17 28-31 * *", async () => {
    if (!isLastDayOfMonth()) return;
    logger.info("[scheduler] running monthly statement");
    await sendMonthlyReportToAll().catch((e: unknown) =>
      logger.error({ err: e }, "[scheduler] monthly statement error"),
    );
  });

  logger.info("[scheduler] notification jobs scheduled (daily/weekly/monthly)");
}
